/*
  # Fix Profiles Table RLS Policies

  1. Changes
    - Add INSERT policy for profiles table to allow users to create their own profile
    - Add UPDATE policy for users to modify their own profile
    
  2. Security
    - Users can only insert/update their own profile data
    - Maintains existing SELECT policy
*/

-- Allow users to insert their own profile
CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Allow users to update their own profile
CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);